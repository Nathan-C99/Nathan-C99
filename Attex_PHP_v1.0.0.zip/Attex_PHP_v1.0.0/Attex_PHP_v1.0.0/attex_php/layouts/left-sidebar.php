<!-- ========== Left Sidebar Start ========== --> 
<div class="leftside-menu">
  <!-- Brand Logo Light -->
  <a href="index.php" class="logo logo-light">
    <span class="logo-lg" style="background-color: blue; display: inline-block; padding: 5px;">
      <img src="assets/images/logo.png" alt="logo" />
    </span>
    <span class="logo-sm" style="background-color: blue; display: inline-block; padding: 5px;">
      <img src="assets/images/logo-sm.png" alt="small logo" />
    </span>
  </a>

  <!-- Brand Logo Dark -->
  <a href="index.php" class="logo logo-dark">
    <span class="logo-lg" style="background-color: blue; display: inline-block; padding: 5px;">
      <img src="assets/images/logo-dark.png" alt="dark logo" />
    </span>
    <span class="logo-sm" style="background-color: blue; display: inline-block; padding: 5px;">
      <img src="assets/images/logo-sm.png" alt="small logo" />
    </span>
  </a>

  <!-- Sidebar Hover Menu Toggle Button -->
  <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
    <i class="ri-arrow-right-s-line align-middle"></i>
  </div>

  <!-- Full Sidebar Menu Close Button -->
  <div class="button-close-fullsidebar">
    <i class="ri-close-line align-middle"></i>
  </div>

  <!-- Sidebar -left -->
  <div class="h-100" id="leftside-menu-container" data-simplebar>
    <!-- Leftbar User -->
    <div class="leftbar-user" style="background-color: dark black; padding: 15px; display: flex; align-items: center;">
      <a href="pages-profile.php" style="color: white; display: flex; align-items: center;">
        <img src="assets/images/users/avatar-1.jpg" alt="user-image" height="42" class="rounded-circle shadow-sm" />
        <div style="margin-left: 10px;">
          <span class="leftbar-user-name">Lunga</span>
          <div style="display: flex; align-items: center;">
            <i class="ri-checkbox-blank-circle-fill" style="color: green; font-size: 10px; margin-right: 5px;"></i>
            <span class="online-status" style="color: green; font-size: 12px;">Online</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Search Bar -->
    <div class="sidebar-search-box px-3 py-2">
      <form action="search-results.php" method="get">
        <div class="input-group">
          <input type="text" class="form-control" placeholder="Search..." name="query" />
          <button class="btn btn-primary" type="submit">
            <i class="ri-search-line"></i>
          </button>
        </div>
      </form>
    </div>

    <!--- Sidemenu -->
    <ul class="side-nav">
      <li class="side-nav-title">MAIN NAVIGATION</li>

      <li class="side-nav-item">
        <a data-bs-toggle="collapse" href="#sidebarDashboards" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
          <i class="ri-home-line"></i>
          <span class="badge bg-success float-end"></span>
          <span> Burial Application </span>
        </a>
        <div class="collapse" id="sidebarDashboards">
          <ul class="side-nav-second-level">
            <li>
              <a href="new-burial.php">New Burial</a>
            </li>
            <li>
              <a href="search-burial.php">Search Burial</a>
            </li>
            <li>
              <a href="burial-browser.php">Burial Browser</a>
            </li>
          </ul>
        </div>
      </li>

      <li class="side-nav-item">
        <a href="graves.php" class="side-nav-link">
          <i class="ri-landscape-line"></i>
          <span> Graves </span>
        </a>
      </li>

      <li class="side-nav-item">
        <a href="ownership.php" class="side-nav-link">
          <i class="ri-user-line"></i>
          <span> Ownership </span>
        </a>
      </li>

      <li class="side-nav-item">
        <a data-bs-toggle="collapse" href="#sidebarMaintenance" aria-expanded="false" aria-controls="sidebarMaintenance" class="side-nav-link">
          <i class="ri-tools-line"></i>
          <span> Maintenance </span>
          <span class="menu-arrow"></span>
        </a>
        <div class="collapse" id="sidebarMaintenance">
          <ul class="side-nav-second-level">
            <li>
              <a href="maintenance-inbox.php">Inbox</a>
            </li>
            <li>
              <a href="maintenance-read.php">Read Email</a>
            </li>
          </ul>
        </div>
      </li>

      <li class="side-nav-item">
        <a data-bs-toggle="collapse" href="#sidebarGIS" aria-expanded="false" aria-controls="sidebarGIS" class="side-nav-link">
          <i class="ri-map-pin-line"></i>
          <span> GIS Viewer </span>
          <span class="menu-arrow"></span>
        </a>
        <div class="collapse" id="sidebarGIS">
          <ul class="side-nav-second-level">
            <li>
              <a href="gis-list.php">List</a>
            </li>
            <li>
              <a href="gis-details.php">Details</a>
            </li>
          </ul>
        </div>
      </li>

      <li class="side-nav-item">
        <a href="survey-data.php" class="side-nav-link">
          <i class="ri-bar-chart-line"></i>
          <span> Survey Data </span>
        </a>
      </li>

      <li class="side-nav-item">
        <a href="service-type.php" class="side-nav-link">
          <i class="ri-customer-service-line"></i>
          <span> Service Type </span>
        </a>
      </li>

      <li class="side-nav-item">
        <a data-bs-toggle="collapse" href="#sidebarReports" aria-expanded="false" aria-controls="sidebarReports" class="side-nav-link">
          <i class="ri-file-chart-line"></i>
          <span> Reports </span>
          <span class="menu-arrow"></span>
        </a>
        <div class="collapse" id="sidebarReports">
          <ul class="side-nav-second-level">
            <li>
              <a href="reports-profile.php">Profile</a>
            </li>
            <li>
              <a href="reports-invoice.php">Invoice</a>
            </li>
            <li>
              <a href="reports-faq.php">FAQ</a>
            </li>
            <li>
              <a href="reports-pricing.php">Pricing</a>
            </li>
            <li>
              <a href="reports-maintenance.php">Maintenance</a>
            </li>
            <li>
              <a href="reports-starter.php">Starter Page</a>
            </li>
            <li>
              <a href="reports-preloader.php">With Preloader</a>
            </li>
            <li>
              <a href="reports-timeline.php">Timeline</a>
            </li>
          </ul>
        </div>
      </li>

      <li class="side-nav-item">
        <a data-bs-toggle="collapse" href="#sidebarTutorials" aria-expanded="false" aria-controls="sidebarTutorials" class="side-nav-link">
          <i class="ri-book-open-line"></i>
          <span> Tutorials </span>
          <span class="menu-arrow"></span>
        </a>
        <div class="collapse" id="sidebarTutorials">
          <ul class="side-nav-second-level">
            <li>
              <a href="tutorials-login.php">Login</a>
            </li>
            <li>
              <a href="tutorials-login-2.php">Login 2</a>
            </li>
            <li>
              <a href="tutorials-register.php">Register</a>
            </li>
            <li>
              <a href="tutorials-register-2.php">Register 2</a>
            </li>
            <li>
              <a href="tutorials-recoverpw.php">Recover Password</a>
            </li>
            <li>
              <a href="tutorials-lock-screen.php">Lock Screen</a>
            </li>
          </ul>
        </div>
      </li>
    </ul>

    <!--- End Sidemenu -->
    <div class="clearfix"></div>
  </div>
</div>
<!-- ========== Left Sidebar End ========== -->
