<?php
// Initialize the session
session_start();

?>