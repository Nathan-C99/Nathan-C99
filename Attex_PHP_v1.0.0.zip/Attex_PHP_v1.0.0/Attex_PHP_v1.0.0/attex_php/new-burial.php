<head>  
    <title>Burial Application | Cemetery Management System</title>
    <?php include 'layouts/title-meta.php'; ?>

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">
    
    <!-- Bootstrap 5 and additional styles -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    
    <?php include 'layouts/head-css.php'; ?>
</head>

<body>
    <!-- Begin page wrapper -->
    <div class="wrapper">
        <?php include 'layouts/menu.php'; ?> <!-- Left-side navigation menu -->

        <!-- Main content -->
        <div class="content-page">
            <div class="content">
                <!-- Container for dashboard content -->
                <div class="container-fluid">
                    <!-- Page title and navigation breadcrumb -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex justify-content-between align-items-center">
                                <h1 class="page-title">Dashboard</h1>
                                <div class="breadcrumb-right">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                        <li class="breadcrumb-item"><a href="index.php">Burial Application</a></li>
                                        <li class="breadcrumb-item active">New Burial</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tip section -->
                    <div class="alert alert-info">
                        <strong>Tip!:</strong> When adding a new burial, you can edit the information later. However, after finalizing the record, editing may not be possible. Ensure all details are correct before saving.
                    </div>

                    <!-- Form sections with clickable tabs -->
                    <div class="row">
                        <div class="col-lg-8">
                            <!-- Tabs for different sections (Burial Type, Deceased Details, etc.) -->
                            <ul class="nav nav-tabs" id="burialTabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="burial-type-tab" data-bs-toggle="tab" href="#burialType" role="tab" aria-controls="burialType" aria-selected="true">Burial Type</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="deceased-details-tab" data-bs-toggle="tab" href="#deceasedDetails" role="tab" aria-controls="deceasedDetails" aria-selected="false">Deceased Details</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="grave-allocation-tab" data-bs-toggle="tab" href="#graveAllocation" role="tab" aria-controls="graveAllocation" aria-selected="false">Grave Allocation</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="availability-details-tab" data-bs-toggle="tab" href="#availabilityDetails" role="tab" aria-controls="availabilityDetails" aria-selected="false">Availability Details</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="next-of-kin-tab" data-bs-toggle="tab" href="#nextOfKin" role="tab" aria-controls="nextOfKin" aria-selected="false">Next of Kin</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="applicant-details-tab" data-bs-toggle="tab" href="#applicantDetails" role="tab" aria-controls="applicantDetails" aria-selected="false">Applicant Details</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="undertaker-detais-tab" data-bs-toggle="tab" href="#undertakerdetails" role="tab" aria-controls="undertakerdetails" aria-selected="false">Undertaker Details</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="required-documents-tab" data-bs-toggle="tab" href="#requireddocuments" role="tab" aria-controls="requireddocuments" aria-selected="false">Required Documents</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="order-details-tab" data-bs-toggle="tab" href="#orderDetails" role="tab" aria-controls="orderDetails" aria-selected="false">Order Details</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="quotation-tab" data-bs-toggle="tab" href="#quotation" role="tab" aria-controls="quotation" aria-selected="false">Quotation</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="receipt-tab" data-bs-toggle="tab" href="#receipt" role="tab" aria-controls="receipt" aria-selected="false">Receipt</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="finalize-application-tab" data-bs-toggle="tab" href="#finalizeapplication" role="tab" aria-controls="finalizeapplication" aria-selected="false">Finalize Application</a>
                                </li>
                                <!-- Add more tabs as needed -->
                            </ul>

                            <!-- Tab content for each section -->
                            <div class="tab-content mt-4" id="burialTabContent">
                                <!-- Burial Type Form -->
                                <div class="tab-pane fade show active" id="burialType" role="tabpanel" aria-labelledby="burial-type-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Burial Type</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_burial_type.php" method="POST">
                                                <div class="form-group">
                                                    <label for="burialTypeSelect">Select Burial Type</label>
                                                    <select id="burialTypeSelect" name="burial_type" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">Cemetery</option>
                                                        <option value="Cremation">Cremation</option>
                                                        <option value="Traditional">Traditional</option>
                                                    </select>
                                                </div>
                                                <div class="mt-3">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                                    <a href="burial-application.php" class="btn btn-secondary">Back to List</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Deceased Details Form -->
                                <div class="tab-pane fade" id="deceasedDetails" role="tabpanel" aria-labelledby="deceased-details-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Deceased Details</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_deceased_details.php" method="POST">
                                                <div class="form-group">
                                                    <label for="deceasedName">Name of Deceased</label>
                                                    <input type="text" id="deceasedName" name="deceased_name" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="deceasedAge">Age</label>
                                                    <input type="number" id="deceasedAge" name="deceased_age" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="dateOfDeath">Date of Death</label>
                                                    <input type="date" id="dateOfDeath" name="date_of_death" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="deceasedName">Id Number</label>
                                                    <input type="text" id="id_number" name="id_number" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="residentSelect"> Resident</label>
                                                    <select id="resident" name="resident" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">South Africa</option>
</select>
</div>
                                                        <div class="form-group mt-2">
                                                    <label for="causeofdeathSelect"> Cause of Death </label>
                                                    <select id="cause_of_death" name="cause_of_death" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">   Natural</option>
                                                        <option value="Cemetery">   Accidental Death</option>
                                                        <option value="Cemetery">   Suicide</opt>
                                                     </select>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="causeofdeathdescriptionSelect"> Cause of Death Description </label>
                                                    <select id="causeofdeathdescription" name="cause_of_death_description" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">   cancer</option>
                                                        <option value="Cemetery">   Heart Attack</option>
                                                        <option value="Cemetery">   Car Accident</opt>
                                                     </select>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="causeofdeathSelect"> Contagious Disease </label>
                                                    <select id="contagious_disease" name="contagious_disease" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">   Yes</option>
                                                        <option value="Cemetery">   No</option>
                                                     </select>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="genderSelect"> Gender </label>
                                                    <select id="gender" name="gender" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">   Female</option>
                                                        <option value="Cemetery">   Male</option>
                                                     </select>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="nationality">Nationality</label>
                                                    <input type="text" id="Nationality" name="nationality" class="form-control" required>
                                                </div>
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Grave Allocation Form -->
                                <div class="tab-pane fade" id="graveAllocation" role="tabpanel" aria-labelledby="grave-allocation-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Grave Allocation</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_grave_allocation.php" method="POST">
                                                <div class="form-group">
                                
                                                    <label for="cemeterySelect"> Cemetery </label>
                                                    <select id="cemetery" name="cemetery" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">Klip Cemetery</option>
                                                      
                                                     </select>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="section">Section</label>
                                                
                                                    <select id="section" name="section" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">   South Side</option>
                                                        <option value="Cemetery">   North Side</option>
                                                     </select>
                                            
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="gravetypeSelect"> Grave Type </label>
                                                    <select id="grave_type" name="grave_type" class="form-select" required>
                                                        <option value="">Choose...</option>
                                                        <option value="Cemetery">  Companion Plots</option>
                                                        
                                                     </select>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="block">Block</label>
                                                    <input type="text" id="block" name="block" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="Row">Row</label>
                                                    <input type="text" id="Nationality" name="row" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="grave">Grave</label>
                                                    <input type="text" id="grave" name="grave" class="form-control" required>
                                                </div>
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Availability Details Form -->
                                <div class="tab-pane fade" id="availabilityDetails" role="tabpanel" aria-labelledby="availability-details-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Availability Details</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_availability_details.php" method="POST">
                                                <div class="form-group">
                                                    <label for="availabilityDate">Availability Date</label>
                                                    <input type="date" id="availabilityDate" name="availability_date" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="graveAvailability">Grave Availability</label>
                                                    <select id="graveAvailability" name="grave_availability" class="form-select" required>
                                                        <option value="">Select</option>
                                                        <option value="Available">Available</option>
                                                        <option value="Not Available">Not Available</option>
                                                    </select>
                                                </div>
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Next of Kin Form -->
                                <div class="tab-pane fade" id="nextOfKin" role="tabpanel" aria-labelledby="next-of-kin-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Next of Kin</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_next_of_kin.php" method="POST">
                                                <div class="form-group">
                                                    <label for="kinName">Next of Kin Name</label>
                                                    <input type="text" id="kinName" name="kin_name" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="kinContact">Contact Number</label>
                                                    <input type="tel" id="kinContact" name="kin_contact" class="form-control" required>
                                                </div>
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Applicant Details Form -->
                                <div class="tab-pane fade" id="applicantDetails" role="tabpanel" aria-labelledby="applicant-details-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Applicant Details</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_applicant_details.php" method="POST">
                                                <div class="form-group">
                                                    <label for="applicantName">Applicant Name</label>
                                                    <input type="text" id="applicantName" name="applicant_name" class="form-control" required>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <label for="applicantContact">Contact Number</label>
                                                    <input type="tel" id="applicantContact" name="applicant_contact" class="form-control" required>
                                                </div>
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
<!-- undertaker Details Form -->
<div class="tab-pane fade" id="undertakerDetails" role="tabpanel" aria-labelledby="undertaker-details-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Undertaker Details</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_applicant_details.php" method="POST">
                                                <div class="form-group">
                                                    <label for="applicantName">Undertaker Name</label>
                                                    <input type="text" id="applicantName" name="applicant_name" class="form-control" required>
                                                </div>
                                                
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- required document Form -->
<div class="tab-pane fade" id="requireddocuments" role="tabpanel" aria-labelledby="required-documents-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Required Documents</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_applicant_details.php" method="POST">
                                            <div class="form-group">
                                                    <label for="documents">Deceased ID Document</label>
                                                    <input type="file" id="decesediddocument" name="documents[]" class="form-control" multiple required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="documents">Death Certificate</label>
                                                    <input type="file" id="deathcertificate" name="documents[]" class="form-control" multiple required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="documents">Burial Order</label>
                                                    <input type="file" id="burialorder" name="documents[]" class="form-control" multiple required>
                                                </div>
                                                
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- Order Details Form -->
<div class="tab-pane fade" id="orderDetails" role="tabpanel" aria-labelledby="order-details-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Order Details</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_applicant_details.php" method="POST">
                                                
                                                
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Generate Order Details</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                 <!-- quotation Form -->
<div class="tab-pane fade" id="quotation" role="tabpanel" aria-labelledby="quotation-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Quotation</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_applicant_details.php" method="POST">
                                            <div class="form-group mt-2">
                                            <label for="genderSelect"> Application Type </label>
                                                    <select id="graveAvailability" name="grave_availability" class="form-select" required>
                                                <div class="form-group">

                                                        <option value="">Select</option>
                                                        <option value="Available">Companion Plots</option>
                                                    
                                                    </select>
                                                </div>
                                                <div class="form-group mt-2">
                                            <label for="genderSelect"> Available Tarrifs </label>
                                                    <select id="graveAvailability" name="grave_availability" class="form-select" required>
                                                <div class="form-group">

                                                        <option value="">Select</option>
                                                        <option value="Available">Cambidge year End Price</option>
                                                    
                                                    </select>
                                                </div>
                                                
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Generate Quotation</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                    
                                        
                                <!-- finalizeapplication Form -->
<div class="tab-pane fade" id="finalizeapplication" role="tabpanel" aria-labelledby="finalize-application-tab">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Finalize Application</h5>
                                        </div>
                                        <div class="card-body">
                                            <form action="submit_applicant_details.php" method="POST">
                                            <div class="form-group mt-2">
                                            <label for="genderSelect"> Status </label>
                                                    <select id="graveAvailability" name="grave_availability" class="form-select" required>
                                                        <option value="">Select</option>
                                                        <option value="Available">Yes</option>
                                                        <option value="Not Available">No</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mt-3">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Add more forms as needed -->
                            </div>
                        </div>

                      <!-- Right-side map -->
  <!-- Right-side map (Municipalities) -->
<div class="col-lg-4">
    <div class="card mb-4">
        <div class="card-header">
            <h5>Municipalities</h5>
        </div>
        <div class="card-body">
            <div id="cemeteryMap" style="width: 105%; height: 350px;">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4378439.853924501!2d25.30918990819422!3d-32.29684042438944!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e646bd57aa61ed7%3A0x5cbad440c9245117!2sEastern%20Cape!5e0!3m2!1sen!2sza!4v1631786615476!5m2!1sen!2sza"
                    width="103%" height="100%" style="border:0;" allowfullscreen="" loading="lazy">
                </iframe>
            </div>

            <!-- Adding Municipalities information -->
            <div class="mt-3">
                <h6>Metropolitan Municipalities: 8</h6>
                <ul>
                   
                </ul>

                <h6>District Municipalities: 44</h6>
                <ul>
                    
                </ul>

                <h6>Local Municipalities: 226</h6>
                <ul>
                    
                </ul>
            </div>
        </div>
    </div>
</div>

</div>

                </div> <!-- End container-fluid -->
            </div> <!-- End content -->
            <?php include 'layouts/footer.php'; ?> <!-- Footer -->
        </div> <!-- End content-page -->
    </div> <!-- End wrapper -->

    <!-- Include necessary scripts -->
    <?php include 'layouts/footer-scripts.php'; ?>
    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <!-- Custom styles -->
    <style>
       .wrapper .left-side {
    background-color: #2d3436; /* Dark background */
    color: white;
}

.left-side .nav-item a {
    color: white;
}

.left-side .nav-item a:hover, .left-side .nav-item a.active {
    background-color: #4a69bd; /* Lighter hover background */
    color: #fff; /* Keep text white */
}

.page-title {
    color: #0984e3; /* Bright blue for titles */
}

.alert-info {
    background-color:#e9f7fd ;
    border-color: #00aaff;
    color: #2d3436;
}

.card-header {
    background-color: #0984e3;
    color: white;
}

.card {
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
}

.btn-primary {
    background-color: #0984e3; /* Bright blue */
    border: none;
}

.btn-secondary {
    background-color: #b2bec3; /* Light grey for secondary */
    border: none;
}

.form-control {
    border: 1px solid #dcdde1;
    box-shadow: none;
    padding: 10px;
    border-radius: 4px;
}

.form-select {
    border: 1px solid #dcdde1;
    padding: 10spx;
}

#cemeteryMap {
    border: 1px solid #dcdde1;
    box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);
}
/* Ensure the footer stays at the bottom of the page without overlapping */
.footer {
    position: relative;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #f8f9fa;
    padding: 10px 0;
    text-align: center;
    z-index: 1000; /* Ensure it stays on top */
}
</style>
</body>


