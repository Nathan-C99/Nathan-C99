<?php
include 'db_connection.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cemetery = $_POST['cemetery'];
    $section = $_POST['section'];
    $grave_type = $_POST['grave_type'];
    $block = $_POST['block'];
    $row = $_POST['row'];
    $grave = $_POST['grave'];

    $stmt = $pdo->prepare("INSERT INTO grave_allocation (cemetery, section, grave_type, block, row, grave) VALUES (:cemetery, :section, :grave_type, :block, :row, :grave)");
    $stmt->bindParam(':cemetery', $cemetery);
    $stmt->bindParam(':section', $section);
    $stmt->bindParam(':grave_type', $grave_type); // Changed from $gravetype to $grave_type
    $stmt->bindParam(':block', $block);
    $stmt->bindParam(':row', $row);
    $stmt->bindParam(':grave', $grave);
    
    if ($stmt->execute()) {
        echo "GRAVE ALLOCATION DETAILS SUBMITTED!!";
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }
} else {
    echo "Invalid request method.";
}
?>