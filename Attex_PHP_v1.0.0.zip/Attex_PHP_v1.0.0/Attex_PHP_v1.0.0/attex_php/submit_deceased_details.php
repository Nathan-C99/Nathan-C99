<?php
include 'db_connection.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $deceased_name = $_POST['deceased_name'];
    $deceased_age = $_POST['deceased_age'];
    $date_of_death = $_POST['date_of_death'];
    $id_number = $_POST['id_number'];
    $resident = $_POST['resident'];
    $cause_of_death = $_POST['cause_of_death'];
    $cause_of_death_description = $_POST['cause_of_death'];
    $contagious_disease = $_POST['contagious_disease'];
    $gender = $_POST['gender'];
    $nationality = $_POST['nationality'];

    $stmt = $pdo->prepare("INSERT INTO deceased (deceased_name, deceased_age, date_of_death, id_number, resident, cause_of_death, cause_of_death_description, contagious_disease, gender, nationality) VALUES (:deceased_name, :deceased_age, :date_of_death, :id_number, :resident, :cause_of_death,:cause_of_death_description, :contagious_disease, :gender, :nationality)");

    $stmt->bindParam(':deceased_name', $deceased_name);
    $stmt->bindParam(':deceased_age', $deceased_age);
    $stmt->bindParam(':date_of_death', $date_of_death);
    $stmt->bindParam(':id_number', $id_number);
    $stmt->bindParam(':resident', $resident);
    $stmt->bindParam(':cause_of_death', $cause_of_death);
    $stmt->bindParam(':cause_of_death_description', $cause_of_death_description);
    $stmt->bindParam(':contagious_disease', $contagious_disease);
    $stmt->bindParam(':gender', $gender);
    $stmt->bindParam(':nationality', $nationality);

    if ($stmt->execute()) {
        echo "Deceased Details submitted!.";
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }
} else {
    echo "Invalid request method.";
}
?>
