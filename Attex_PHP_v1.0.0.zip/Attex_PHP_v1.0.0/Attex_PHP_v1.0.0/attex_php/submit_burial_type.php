<?php
include 'db_connection.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $burial_type = $_POST['burial_type'];

    $stmt = $pdo->prepare("INSERT INTO burials (burial_type) VALUES (:burial_type)");
    $stmt->bindParam(':burial_type', $burial_type);

    if ($stmt->execute()) {
        echo "BURIAL TYPE SUBMITTED!.";
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }
} else {
    echo "Invalid request method.";
}
?>
